<?php
// Heading 
$_['heading_title']     = 'Newsletter Subscribers';

// Text
$_['column_email']		= 'Email';

$_['text_empty']		= 'No subscribers to list.';
$_['text_success']		= 'You have successfully deleted subscribers!';

$_['error_warning']		= 'You do not have permission to modify the subscribers!';