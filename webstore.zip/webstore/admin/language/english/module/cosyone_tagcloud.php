<?php
// Heading
$_['heading_title']       = 'Cosyone Popular Tags';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Success: You have modified module Cosyone Twitter feed';

// Entry

$_['entry_status']        = 'Status';
$_['entry_generate']      = 'Generate tags';
$_['entry_title']      	  = 'Module Title';
$_['entry_limit']      	  = 'Tags Limit';

$_['text_info']      	  = 'Please note that you need to manually use the Generate button to refresh the tab collection for this module';
$_['text_success']        = 'Product tags were successfully saved';


// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Cosyone Popular Tags';