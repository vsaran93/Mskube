<?php
// Heading
$_['heading_title']     = 'Cosyone Brand Thumb On Product Page';

//Text
$_['text_module']       = 'Modules';
$_['text_success']      = 'Success: You have modified Cosyone Brand Thumb On Product Page';

//Entry
$_['entry_width']      	= 'Image width';
$_['entry_height']      = 'Image height';
$_['entry_status']      = 'Status';

//Error
$_['error_permission']  = 'Warning: You do not have permission to modify Cosyone Brand Thumb On Product Page';