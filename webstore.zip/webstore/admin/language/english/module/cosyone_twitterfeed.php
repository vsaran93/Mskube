<?php
// Heading
$_['heading_title']        = 'Cosyone Twitter Feed';

//Text
$_['text_module']          = 'Modules';
$_['text_success']         = 'Success: You have modified Cosyone Twitter Feed';
$_['text_edit']            = 'Cosyone Twitter Feed';

//Entry
$_['entry_client_id']      = 'Client ID';
$_['entry_locale']         = 'Locale';
$_['entry_status']         = 'Status';

//Help
$_['help_locale']          = 'This is the PayPal locale setting for your store languages';

//Error
$_['error_permission']     = 'Warning: You do not have permission to modify Cosyone Twitter Feed';