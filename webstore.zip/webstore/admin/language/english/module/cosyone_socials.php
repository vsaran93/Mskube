<?php
// Heading
$_['heading_title']       	= 'Cosyone Social Icons';
$_['button_save_stay']      = 'Save & Stay';
$_['text_edit']       	  	= 'Edit Cosyone Social Icons';
$_['text_module']        	= 'Modules';
$_['entry_status']        	= 'Status';
$_['entry_name']        	= 'Module Name';

// Left side modules list
$_['entry_title']    		= 'Heading';
$_['entry_media']    		= 'Social Media';
$_['entry_link']    		= 'Target URL <small>Use URL including http://</small>';
$_['entry_blank']    		= 'Open link in new window?';
$_['entry_tooltip']    		= 'Tooltip';

// Notifications
$_['text_success']        	= 'Success: You have modified module Cosyone Social Icons';
$_['error_permission']      = 'Warning: You do not have permission to modify the module Cosyone Social Icons';